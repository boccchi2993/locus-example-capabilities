"""TEST ONLY stand-in for the et_xmlfile distribution.

This minimal package exists so the py-et-version-clash fixture can carry a
genuine pure-Python wheel at version 2.0.1 — different from the vendor wheel
(2.0.0) — to exercise local-plugin precedence and the registration version
clash. It implements nothing.
"""

__version__ = "2.0.1"
